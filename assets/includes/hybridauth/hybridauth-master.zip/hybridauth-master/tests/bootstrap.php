<?php namespace HybridauthTest;

require __DIR__ . '/../vendor/autoload.php';
