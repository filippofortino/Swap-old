<?php namespace HybridauthTest\Hybridauth;

use Hybridauth\Hybridauth;

class HybridauthTest extends \PHPUnit_Framework_TestCase
{
    public function test_pass()
    {
        $this->assertTrue(true);
    }
}
